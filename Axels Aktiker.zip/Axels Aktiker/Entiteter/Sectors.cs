﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entiteter
{
    public class Sectors
    {
        public int SectorID { get; set; }
        public string SectorName { get; set; }

        public Sectors(int sectorID, string sectorName)
        {
            SectorID = sectorID;
            SectorName = sectorName;
        }

    }
    
   
}
