﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entiteter
{
    public class StockInPortfolio
    {
        public int StockID { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal BuyPrice { get; set; }
        public decimal CurrentPrice { get; set; }
        public StockInPortfolio(int stockID, string name, int quantity, decimal buyPrice, decimal currentPrice) 
        { 
            StockID = stockID;
            Name = name;
            Quantity = quantity;
            BuyPrice = buyPrice;
            CurrentPrice = currentPrice;
        }
    }
}
