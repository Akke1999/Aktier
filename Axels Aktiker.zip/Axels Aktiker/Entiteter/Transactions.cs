﻿namespace Entiteter
{
    public class Transactions
    {
        public int TransactionID { get; set; }
        public int StockID { get; set; }
        public int FundID { get; set; }
        public decimal BuyPrice { get; set; }
        public decimal SellPrice { get; set; }
        public int Quantity { get; set; }
        public DateTime PurchaseDate { get; set; }
        public DateTime SoldDate { get; set; }
        public string TradeCurrency { get; set; }

        public Transactions(int transactionsID, int stockID, int fundID, decimal buyPrice, decimal sellPrice, int quantity, DateTime purchaseDate,
            DateTime soldDate, string tradeCurrency)
        {
            TransactionID = transactionsID;
            StockID = stockID;
            FundID = fundID;
            BuyPrice = buyPrice;
            SellPrice = sellPrice;
            Quantity = quantity;
            PurchaseDate = purchaseDate;
            SoldDate = soldDate;
            TradeCurrency = tradeCurrency;

        }

    }
}
