﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entiteter
{
    public class Fund
    {
        public int FundID { get; set; }
        public string Name { get; set; }
        public string ISIN { get; set; }
        public decimal Fee { get; set; }

        public Fund(int fundID, string name, string isin, decimal fee)
        {
            FundID = fundID;
            Name = name;
            ISIN = isin;
            Fee = fee;
        }
    }
}
