﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entiteter
{
    public class SnapShot
    {
        public int SnapShotID { get; set; }
        public DateTime SnapShotDate { get; set; }
        public decimal PortfolioValue { get; set; }

        public SnapShot(int snapShotID, DateTime snapShotDate, decimal portfolioValue) 
        {
            SnapShotID = snapShotID;
            SnapShotDate = snapShotDate;
            PortfolioValue = portfolioValue;
        }
    }
}
