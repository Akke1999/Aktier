﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entiteter
{
    public class Stock
    {
        public int StockID { get; set; }
        public string Name { get; set; }
        public string Symbol { get; set; }
        public decimal CurrentPrice { get; set; }
        public int SectorID { get; set; }

        public Stock(int stockID, string name, string symbol, decimal CurrentPrice, int sectorID)
        {
            StockID = stockID;
            Name = name;
            Symbol = symbol;
            SectorID = sectorID;
        }
    }
}
