﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datalager;
using Entiteter;

namespace Affärslager
{
    public class TransactionsKontroller
    {
        private Databas _databas;

        public TransactionsKontroller()
        {
            _databas = new Databas();
        }

        public int StockQuantity(int stockID)
        {
            int registeredStock =_databas.GetStockID(stockID);

            if (registeredStock > 0)
            {
                int quantity = _databas.GetStockQuantity(stockID);
                return quantity;
            }
            else
            {
                return 0;
            }
        }

        public void CreateTransaction(int stockID, int fundID, decimal buyPrice, decimal sellPrice, int quantity, DateTime purchaseDate,
            DateTime soldDate, string tradeCurrency)
        {
            // Lägg till felhantering!
            _databas.CreateTransaction(stockID, fundID, buyPrice, sellPrice, quantity, purchaseDate, soldDate, tradeCurrency);
        }

        public void CreateBuyStockTransaction(int stockID, decimal buyPrice, int quantity, DateTime purchaseDate, string tradeCurrency)
        {

            // Lägg till felhantering!
            
            _databas.CreateBuyStockTransaction(stockID, buyPrice,  quantity, purchaseDate, tradeCurrency);
        }

        public void CreateSellStockTransaction(int stockID, decimal sellPrice, int soldQuantity, DateTime soldDate)
        {
            int currentQuantity = StockQuantity(stockID);
            int newQuantity = currentQuantity - soldQuantity;
            // Lägg till felhantering
            _databas.CreateSellStockTransaction(stockID, sellPrice, newQuantity, soldDate);
        }
    }
}
