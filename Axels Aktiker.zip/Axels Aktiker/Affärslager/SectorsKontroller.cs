﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Datalager;
using Entiteter;

namespace Affärslager
{
    public class SectorsKontroller
    {
        private Databas _databas;

        public SectorsKontroller()
        {
            _databas = new Databas();
        }

        public void AddSector(string newSectorName)
        {
            if (string.IsNullOrWhiteSpace(newSectorName))
            {
                throw new ArgumentNullException("Sektorn måste anges!");
            }

            //Kolla så att sektorn inte redan finns
 

        }
        public List<Sectors> GetSectors() 
        {
            return _databas.GetSectors();
        }


        public int GetOrCreateSector(string newSectorName)
        {
            return _databas.GetOrCreateSector(newSectorName);
        }

    }

}
