﻿using Entiteter;
using Datalager;

namespace Affärslager

{
    public class AktierKontroller
    {
        private Databas _databas;

        public AktierKontroller()
        {
            _databas = new Databas();
        }

        public void AddStock(string name, string symbol, decimal currentPrice, int sectorID)
        {
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(symbol))
            {
                throw new ArgumentException("Namn och Symbol måste anges.");
            }
            if (currentPrice < 0)
            {
                throw new ArgumentException("Priser måste vara 0 eller högre.");
            }
            
            _databas.AddStock(name, symbol, currentPrice, sectorID);
        }

        public List<Stock> GetAllStocks()
        {
            return _databas.GetAllStocks();
        }

        public int GetStockIDFromSymbol(string symbol)
        {
           return _databas.GetStockIDFromSymbol(symbol);
        }

            


        public void UpdateStockPrice(int stockID, decimal newPrice)
        {
            if (newPrice < 0)
            {
                throw new ArgumentException("Priset måste vara högre än 0");
            }

            _databas.UpdateStockPrice(stockID, newPrice);

        }
        public int GetHighestStockID()
        {
            int highestStockID = _databas.GetHighestStockID();
            if (highestStockID < 0)
            {
                return highestStockID;
            }
            else
            {
                return 0;
            }

        }

    }
}
