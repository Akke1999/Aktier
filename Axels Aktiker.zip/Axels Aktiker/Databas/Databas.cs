﻿using Entiteter;
using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Collections;

namespace Datalager
{
    public class Databas
    {
        private string _connectionString;

        // Konstruktor för att initiera connection string
        public Databas()
        {
            _connectionString = "Data Source=Axels;Initial Catalog=Stocks;Integrated Security=True;TrustServerCertificate=True";
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }

        #region Generella databasmetoder

        public int ExecuteNonQuery(string query, List<SqlParameter> parameters)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters.ToArray());
                    }
                    return command.ExecuteNonQuery();
                }
            }
        }

        public DataTable ExecuteQuery(string query, List<SqlParameter> parameters)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        command.Parameters.AddRange(parameters.ToArray());
                    }

                    using (var adapter = new SqlDataAdapter(command))
                    {
                        var table = new DataTable();
                        adapter.Fill(table);
                        return table;
                    }
                }
            }
        }

        #endregion

        #region CRUD för Stocks

        public void AddStock(string name, string symbol, decimal currentPrice, int sectorID)
        {
            string query = "INSERT INTO Stocks (Name, Symbol, CurrentPrice, SectorID)" +
                " VALUES (@Name, @Symbol,@CurrentPrice, @SectorID)";
            var parameters = new List<SqlParameter>
        {
            new SqlParameter("@Name", name),
            new SqlParameter("@Symbol", symbol),
            new SqlParameter("@CurrentPrice", currentPrice),
            new SqlParameter("@SectorID", sectorID)
        };

            ExecuteNonQuery(query, parameters);
        }

        public List<Stock> GetAllStocks()
        {
            string query = "SELECT * FROM Stocks";
            var table = ExecuteQuery(query, null);

            var stocks = new List<Stock>();
            foreach (DataRow row in table.Rows)
            {
                stocks.Add(new Stock(
                    (int)row["StockID"],
                    (string)row["Name"],
                    (string)row["Symbol"],
                    (decimal)row["CurrentPrice"],
                    (int)row["SectorID"]

                ));
            }

            return stocks;
        }

        public int GetHighestStockID()
        {
            string query = "SELECT MAX(StockID) as MaxStockID FROM Stocks";
            var table = ExecuteQuery(query, null);
            if (table.Rows.Count > 0 && table.Rows[0]["MaxStockID"] != DBNull.Value)
            {
                return (int)table.Rows[0]["MaxStockID"];
            }
            else
            {
                return 0;
            }
        }

        public int GetStockID (int stockID) // Om stocken inte finns är värdet 0!
        {
            string query = "Select StockID FROM Stocks WHERE StockID = @stockID";

            var parametersCheck = new List<SqlParameter>
                {
                    new SqlParameter("@stockID", stockID)
                };

            var table = ExecuteQuery(query, parametersCheck);

            if (table.Rows.Count > 0)
            {  
                return (int)table.Rows[0]["StockID"]; 
            }

            else 
            {
                return 0;
            }
        }

        public int GetStockIDFromSymbol(string symbol) // Om stocken inte finns är värdet 0!
        {
            string query = "Select StockID FROm Stocks WHERE Symbol = @symbol";
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@symbol", symbol)
            };
            var table = ExecuteQuery(query, parameters);
            
            if (table.Rows.Count > 0)
            {
                return (int)table.Rows[0]["StockID"];
            }
            else
            {
                return 0;
            }

        }




        public List<StockInPortfolio> GetStocksInPortfolio()
        {
            string query = "SELECT s.StockID, s.Name, t.Quantity, t.BuyPrice, s.CurrentPrice" +
                            "FROM Transactions t " +
                            "JOIN Stocks s ON t.StockID = s.StockID" +
                            "WHERE t.SoldDate IS NULL AND SellPrice is NULL";
            var table = ExecuteQuery(query, null);
            var stockPortfolio = new List<StockInPortfolio>();
            foreach (DataRow row in table.Rows)
            {
                stockPortfolio.Add(new StockInPortfolio(
                    (int)row["StockID"],
                    (string)row["Name"],
                    (int)row["Quantity"],
                    (decimal)row["BuyPrice"],
                    (decimal)row["CurrentPrice"]
                ));
            }
            
            return stockPortfolio;

        }

        /*
        public List<FollowedStocks> GetFollowedStocks()     SKAPA ENTITETEN FOLLOWEDSTOCKS  
        {
            string query = "Select * FROM Stocks ";
        }
        */
        /*
        public List <SoldStocks> GetSoldStocks()            SKAPA ENTITETEN SOLDSTOCKS
        {

        }
        */

        public void UpdateStock(int stockID, string name, string symbol, decimal currentPrice, int sectorID)
        {
            string query = "UPDATE Stocks SET Name = @Name, Symbol = @Symbol, CurrentPrice = @CurrentPrice ,SectorID = @SectorID, WHERE StockID = @StockID";
            var parameters = new List<SqlParameter>
        {
            new SqlParameter("@StockID", stockID),
            new SqlParameter("@Name", name),
            new SqlParameter("@Symbol", symbol),
            new SqlParameter("@CurrentPrice", currentPrice),
            new SqlParameter("@SectorID", sectorID)
        };

            ExecuteNonQuery(query, parameters);
        }

        public void UpdateStockPrice(int stockID, decimal newCurrenPrice)
        {
            string query = "UPDATE Stocks SET CurrentPrice = @CurrentPrice WHERE StockID = @StockID";
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@StockID", stockID),
                new SqlParameter("@CurrentPrice", newCurrenPrice)
            };

            ExecuteNonQuery(query, parameters);
        }


        public void DeleteStock(int stockID)
        {
            string query = "DELETE FROM Stocks WHERE StockID = @StockID";
            var parameters = new List<SqlParameter>
        {
            new SqlParameter("@StockID", stockID)
        };

            ExecuteNonQuery(query, parameters);
        }

        public decimal GetCurrentStockPrice(int stockID)
        {
            string query = "SELECT CurrentPrice FROM Stocks WHERE StockID = @StockID";
            var parameters = new List<SqlParameter>
        {
            new SqlParameter("@StockID", stockID)
        };

            var table = ExecuteQuery(query, parameters);
            if (table.Rows.Count > 0)
            {
                return (decimal)table.Rows[0]["Price"];
            }
            else
            {
                throw new Exception("Inget pris hittades för aktien.");
            }
        }

        #endregion

        #region CRUD för Funds

        public void AddFund(string name, string isin, decimal fee)
        {
            string query = "INSERT INTO Funds (Name, ISIN, Fee) VALUES (@Name, @ISIN, @Fee)";
            var parameters = new List<SqlParameter>
        {
            new SqlParameter("@Name", name),
            new SqlParameter("@ISIN", isin),
            new SqlParameter("@Fee", fee)
        };

            ExecuteNonQuery(query, parameters);
        }

        public List<Fund> GetAllFunds()
        {
            string query = "SELECT * FROM Funds";
            var table = ExecuteQuery(query, null);

            var funds = new List<Fund>();
            foreach (DataRow row in table.Rows)
            {
                funds.Add(new Fund(
                    (int)row["FundID"],
                    (string)row["Name"],
                    (string)row["ISIN"],
                    (decimal)row["Fee"]
                ));
            }

            return funds;
        }

        public int CheckForFund(int fundID)
        {
            string query = "Select FundID FROM Funds WHERE FundID = @fundID";

            var parametersCheck = new List<SqlParameter>
                {
                    new SqlParameter("@fundID", fundID)
                };

            var table = ExecuteQuery(query, parametersCheck);

            if (table.Rows.Count > 0)
            {
                return (int)table.Rows[0]["FundID"];
            }

            else
            {
                return 0;
            }

        }


        public void UpdateFund(int fundID, string name, string isin, decimal fee)
        {
            string query = "UPDATE Funds SET Name = @Name, ISIN = @ISIN, Fee = @Fee WHERE FundID = @FundID";
            var parameters = new List<SqlParameter>
            {
            new SqlParameter("@FundID", fundID),
            new SqlParameter("@Name", name),
            new SqlParameter("@ISIN", isin),
            new SqlParameter("@Fee", fee)
            };

            ExecuteNonQuery(query, parameters);
        }

        public void DeleteFund(int fundID)
        {
            string query = "DELETE FROM Funds WHERE FundID = @FundID";
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@FundID", fundID)
            };

            ExecuteNonQuery(query, parameters);
        }

        #endregion

        #region CRUD för Transactions

        

        public void CreateTransaction(int stockID, int fundID, decimal buyPrice, decimal sellPrice, int quantity, DateTime purchaseDate,
            DateTime soldDate, string tradeCurrency)
        {
            string transActionQuery = "INSERT INTO Transactions (StockID, FundID, BuyPrice, SellPrice," +
                " Quantity, PurchaseDate, SoldDate, TradeCurrency)" +
                "VALUES (@stockID, @fundID, @buyPrice, @sellPrice, @quantity, @purchaseDate, @soldDate, @tradeCurrency)";
            var transActionParameters = new List<SqlParameter>
            {
                new SqlParameter ("@stockID", stockID),
                new SqlParameter ("@fundID", fundID),
                new SqlParameter ("@buyPrice", buyPrice),
                new SqlParameter ("@sellPrice", sellPrice),
                new SqlParameter ("@quantity", quantity),
                new SqlParameter ("@purchaseDate", purchaseDate),
                new SqlParameter ("@soldDate", soldDate),
                new SqlParameter ("@tradeCurrency", tradeCurrency)
            };

            ExecuteNonQuery(transActionQuery, transActionParameters);
        }

        public void CreateBuyStockTransaction(int stockID, decimal buyPrice, int quantity, DateTime purchaseDate, string tradeCurrency)
        {
            string transActionQuery = "INSERT INTO Transactions (StockID, BuyPrice," +
                " Quantity, PurchaseDate, TradeCurrency)" +
                "VALUES (@stockID, @buyPrice, @quantity, @purchaseDate, @tradeCurrency)";
            var transActionParameters = new List<SqlParameter>
            {
                new SqlParameter ("@stockID", stockID),
                new SqlParameter ("@buyPrice", buyPrice),
                new SqlParameter ("@quantity", quantity),
                new SqlParameter ("@purchaseDate", purchaseDate),
                new SqlParameter ("@tradeCurrency", tradeCurrency)
            };

            ExecuteNonQuery(transActionQuery, transActionParameters);
        }

        public void CreateSellStockTransaction(int stockID, decimal sellPrice, int quantity, DateTime soldDate)
        {
            string transActionQuery = "INSERT INTO Transactions (StockID, SellPrice," +
                " Quantity, SoldDate)" +
                "VALUES (@stockID, @sellPrice, @quantity, @soldDate)";
            var transActionParameters = new List<SqlParameter>
            {
                new SqlParameter ("@stockID", stockID),
                new SqlParameter ("@sellPrice", sellPrice),
                new SqlParameter ("@quantity", quantity),
                new SqlParameter ("@soldDate", soldDate)
            };

            ExecuteNonQuery(transActionQuery, transActionParameters);
        }


        public int GetStockQuantity(int stockID)
        {
            string checkQuery = "SELECT Quantity FROM Transactions WHERE StockID = @stockID";
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@stockID", stockID)
            };

            var table = ExecuteQuery(checkQuery, parameters);

            if (table.Rows.Count > 0)
            {
                return (int)table.Rows[0]["Quantity"];
            }
            else 
            {
                return 0;
            }
        }

        public void SellStock(int stockID, decimal sellPrice, int newQuantity, DateTime soldDate)
        {
            string sellQuery = "UPDATE Transactions SET SellPrice = @sellPrice, Quantity = @newQuantity, SoldDate = @soldDate WHERE StockID = @stockID";

            var sellParameteres = new List<SqlParameter>
            {
                new SqlParameter("@stockID", stockID),
                new SqlParameter ("@sellPrice", sellPrice),
                new SqlParameter ("@newQuantity", newQuantity),
                new SqlParameter ("@soldDate", soldDate)
            };
        }

        #endregion

        #region CRUD för Sectors
        public void AddSector(string newSectorName)
        {
            string query = "INSERT INTO Sectors (SectorName) VALUES (@SectorName)";
            var parameters = new List<SqlParameter>
            {
            new SqlParameter("@SectorName", newSectorName),

        };

            ExecuteNonQuery(query, parameters);
        }

        public List<Sectors> GetSectors()
        {
            string query = "SELECT * FROM Sectors";
            var table = ExecuteQuery(query, null);

            var sector = new List<Sectors>();
            foreach (DataRow row in table.Rows)
            {
                sector.Add(new Sectors(
                    (int)row["SectorID"],
                    (string)row["SectorName"]

                ));
            }
            return sector;
        }

        public int GetOrCreateSector(string newSectorName)
        {
            // Kontrollera om sektorn redan finns
            string queryCheck = "SELECT SectorID FROM Sectors WHERE SectorName = @SectorName";

            // Skapa nya parametrar för denna fråga
            var parametersCheck = new List<SqlParameter>
            {
                new SqlParameter("@SectorName", newSectorName) // Skapar en ny parameter
            };

            var table = ExecuteQuery(queryCheck, parametersCheck); // Kör frågan med nya parametrar

            // Om sektorn finns, returnera SectorID
            if (table.Rows.Count > 0)
            {
                return (int)table.Rows[0]["SectorID"];
            }

            // Annars, skapa en ny sektor
            else
            {
                // Skapa en ny sektor
                AddSector(newSectorName);

                // Skapa nya parametrar för att hämta det nya SectorID
                string queryGetNewSectorId = "SELECT SectorID FROM Sectors WHERE SectorName = @SectorName";

                var parametersGetNew = new List<SqlParameter>
                {
                    new SqlParameter("@SectorName", newSectorName) // Skapar en ny parameter för denna fråga
                };

                var newTable = ExecuteQuery(queryGetNewSectorId, parametersGetNew); // Kör frågan med nya parametrar

                // Returnera det nya SectorID
                return (int)newTable.Rows[0]["SectorID"];
            }
        }

            #endregion

            #region Specifika tabeller

            public DataTable GetCombinedPortfolio()
        {
            var dataTable = new DataTable();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                // SQL för att slå samman data från båda tabellerna
                var query = @"
            SELECT 'Stock' AS Type, StockName AS Name, Quantity, Value
            FROM StockPortfolio
            UNION ALL
            SELECT 'Fund' AS Type, FundName AS Name, Quantity, Value
            FROM FundPortfolio
        ";

                using (var command = new SqlCommand(query, connection))
                {
                    using (var adapter = new SqlDataAdapter(command))
                    {
                        adapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }


        #endregion

    }
}
