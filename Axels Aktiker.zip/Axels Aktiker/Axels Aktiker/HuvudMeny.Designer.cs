﻿namespace Axels_Aktiker
{
    partial class HuvudMeny
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Innehav = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Innehav
            // 
            this.Innehav.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Innehav.AutoSize = true;
            this.Innehav.Location = new System.Drawing.Point(102, 83);
            this.Innehav.Name = "Innehav";
            this.Innehav.Size = new System.Drawing.Size(149, 65);
            this.Innehav.TabIndex = 0;
            this.Innehav.Text = "Innehav";
            this.Innehav.UseVisualStyleBackColor = true;
            this.Innehav.Click += new System.EventHandler(this.Innehav_Click);
            // 
            // HuvudMeny
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(790, 561);
            this.Controls.Add(this.Innehav);
            this.Name = "HuvudMeny";
            this.Text = "Axel Stocks";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Innehav;
    }
}

