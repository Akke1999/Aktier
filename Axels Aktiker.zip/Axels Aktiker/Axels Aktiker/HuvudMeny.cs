﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Axels_Aktiker
{
    public partial class HuvudMeny : Form
    {
        public HuvudMeny()
        { 
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void Innehav_Click(object sender, EventArgs e)
        {
            this.Hide();
            Innehav innehav = new Innehav();
            innehav.Show();

        }

    }
}
