﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class PortfolioMeny : BaseForm
    {
        public PortfolioMeny()
        {
            InitializeComponent();
        }

        private void FullPortfolio_Click(object sender, EventArgs e)
        {

            TotalPortfolioMeny totalPortfolioMeny = new TotalPortfolioMeny();
            totalPortfolioMeny.ShowDialog();

        }

        private void AddStockBtn_Click(object sender, EventArgs e)
        {
            
            AddStockToPortfolioMeny addStockToPortfolioMeny = new AddStockToPortfolioMeny();
            addStockToPortfolioMeny.ShowDialog();
        }
    }
}
