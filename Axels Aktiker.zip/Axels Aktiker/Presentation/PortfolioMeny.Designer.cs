﻿namespace Presentation
{
    partial class PortfolioMeny
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AddStockBtn = new Button();
            FullPortfolio = new Button();
            StockPortfolioBtn = new Button();
            AddFundsBtn = new Button();
            FundPortfolioBtn = new Button();
            SuspendLayout();
            // 
            // AddStockBtn
            // 
            AddStockBtn.Anchor = AnchorStyles.None;
            AddStockBtn.AutoSize = true;
            AddStockBtn.Location = new Point(427, 272);
            AddStockBtn.Name = "AddStockBtn";
            AddStockBtn.Size = new Size(171, 75);
            AddStockBtn.TabIndex = 5;
            AddStockBtn.Text = "Lägg till aktier";
            AddStockBtn.UseVisualStyleBackColor = true;
            AddStockBtn.Click += AddStockBtn_Click;
            // 
            // FullPortfolio
            // 
            FullPortfolio.Anchor = AnchorStyles.None;
            FullPortfolio.AutoSize = true;
            FullPortfolio.Location = new Point(54, 145);
            FullPortfolio.Name = "FullPortfolio";
            FullPortfolio.Size = new Size(171, 75);
            FullPortfolio.TabIndex = 4;
            FullPortfolio.Text = "Visa det totala innehavet";
            FullPortfolio.UseVisualStyleBackColor = true;
            FullPortfolio.Click += FullPortfolio_Click;
            // 
            // StockPortfolioBtn
            // 
            StockPortfolioBtn.Anchor = AnchorStyles.None;
            StockPortfolioBtn.AutoSize = true;
            StockPortfolioBtn.Location = new Point(308, 145);
            StockPortfolioBtn.Name = "StockPortfolioBtn";
            StockPortfolioBtn.Size = new Size(171, 75);
            StockPortfolioBtn.TabIndex = 6;
            StockPortfolioBtn.Text = "Visa aktie innehav";
            StockPortfolioBtn.UseVisualStyleBackColor = true;
            // 
            // AddFundsBtn
            // 
            AddFundsBtn.Anchor = AnchorStyles.None;
            AddFundsBtn.AutoSize = true;
            AddFundsBtn.Location = new Point(175, 272);
            AddFundsBtn.Name = "AddFundsBtn";
            AddFundsBtn.Size = new Size(171, 75);
            AddFundsBtn.TabIndex = 7;
            AddFundsBtn.Text = "Lägg till fonder";
            AddFundsBtn.UseVisualStyleBackColor = true;
            // 
            // FundPortfolioBtn
            // 
            FundPortfolioBtn.Anchor = AnchorStyles.None;
            FundPortfolioBtn.AutoSize = true;
            FundPortfolioBtn.Location = new Point(540, 145);
            FundPortfolioBtn.Name = "FundPortfolioBtn";
            FundPortfolioBtn.Size = new Size(171, 75);
            FundPortfolioBtn.TabIndex = 8;
            FundPortfolioBtn.Text = "Visa fond innehav";
            FundPortfolioBtn.UseVisualStyleBackColor = true;
            // 
            // PortfolioMeny
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 510);
            Controls.Add(FundPortfolioBtn);
            Controls.Add(AddFundsBtn);
            Controls.Add(StockPortfolioBtn);
            Controls.Add(AddStockBtn);
            Controls.Add(FullPortfolio);
            Name = "PortfolioMeny";
            Controls.SetChildIndex(FullPortfolio, 0);
            Controls.SetChildIndex(AddStockBtn, 0);
            Controls.SetChildIndex(StockPortfolioBtn, 0);
            Controls.SetChildIndex(AddFundsBtn, 0);
            Controls.SetChildIndex(FundPortfolioBtn, 0);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button rapporterBtn;
        private Button AddStockBtn;
        private Button FullPortfolio;
        private Button StockPortfolioBtn;
        private Button AddFundsBtn;
        private Button FundPortfolioBtn;
    }
}