﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentation
{
    public class BaseForm : Form
    {
        private Button returnButton;
        private bool _isSafeToClose = false;


        public BaseForm()

        {
            InitializeMenuStrip();
            //Färg
            this.BackColor = Color.FromArgb(46, 46, 46);

            //Fönster
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(800, 600);

            //Font
            this.Font = new Font("Segoe UI", 10);

            //Lite mer stillat
            this.FormBorderStyle = FormBorderStyle.FixedDialog; // Ingen fönsterförändring
            this.MaximizeBox = false; // Ingen maximering
            this.Text = "Axels Aktier";

            InitalizeReturnButton();

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (!_isSafeToClose)
            {
                var result = MessageBox.Show("Vill du verkligen avsluta?", "Avsluta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    Environment.Exit(0);
                }
                else
                {
                    e.Cancel = true;
                }
            }


        }

        private void InitalizeReturnButton()
        {
            returnButton = new Button
            {
                Size = new Size(40, 30),
                Location = new Point(12, 47),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                BackgroundImage = Properties.Resources.PilBakåt,
                BackgroundImageLayout = ImageLayout.Stretch,
                FlatAppearance = { BorderSize = 0, }
            };

            returnButton.Click += ReturnButton_Click;
            this.Controls.Add(returnButton);
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            _isSafeToClose = true; // Tillåt säker stängning
            this.Close(); // Stäng formuläret
            HuvudMeny huvudMeny = new HuvudMeny();
            huvudMeny.Show();
        }

        public void HideReturnButton()
        {
            returnButton.Visible = false;
        }
        public void ShowReturnButton()
        {
            returnButton.Visible = true; // Visa knappen om det behövs
        }

        private void InitializeComponent()
        {

        }

        private void InitializeMenuStrip() // Används för att snabbare navigera!
        {

            var menuStrip = new MenuStrip();
            menuStrip.BackColor = Color.FromArgb(46, 46, 46);
            menuStrip.ForeColor = Color.White;
            menuStrip.Font = new Font("Segoe UI", 10);


            var fileMenu = new ToolStripMenuItem("Fil");
            fileMenu.DropDownItems.Add("Avsluta", null, (s, e) => this.Close());
            /*
            var viewMenu = new ToolStripMenuItem("Visa");
            viewMenu.DropDownItems.Add("Innehav", null, (s, e) =>
            {
                var innehavForm = new PortfolioMeny();
                innehavForm.Show();
            });
            viewMenu.DropDownItems.Add("Aktier", null, (s, e) =>
            {
                var aktierForm = new StocksMeny();
                aktierForm.Show();
            });
            */

            var helpMenu = new ToolStripMenuItem("Hjälp");
            helpMenu.DropDownItems.Add("Om programmet", null, (s, e) =>
            {
                MessageBox.Show("Detta är ett aktiehanteringssystem, version 1.0.");
            });

            menuStrip.Items.Add(fileMenu);
            //menuStrip.Items.Add(viewMenu);
            menuStrip.Items.Add(helpMenu);


            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);
        }

        //private MenuStrip menuStrip1;
    }

}

