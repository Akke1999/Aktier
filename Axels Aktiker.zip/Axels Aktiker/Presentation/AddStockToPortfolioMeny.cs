﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Affärslager;

namespace Presentation
{
    public partial class AddStockToPortfolioMeny : BaseForm2
    {
        AktierKontroller aktierKontroller = new AktierKontroller();
        public AddStockToPortfolioMeny()
        {

            InitializeComponent();
        }

        private void AddStockBtn_Click(object sender, EventArgs e)
        {
            SectorsKontroller sectorsKontroller = new SectorsKontroller();
            TransactionsKontroller transactionsKontroller = new TransactionsKontroller();
            string name = txtName.Text;
            string symbol = txtSymbol.Text;
            string sector = txtSektor.Text;
            if (string.IsNullOrEmpty(CBCurrency.Text) || CBCurrency.Text == "Valuta")
            {
                MessageBox.Show("Välj en valuta (SEK, EUR, USD)", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kontrollera att texten inte är för lång och matchar förväntade valutor
            if (CBCurrency.Text.Length != 3 || !(CBCurrency.Text == "SEK" || CBCurrency.Text == "EUR" || CBCurrency.Text == "USD"))
            {
                MessageBox.Show("Välj en giltig valuta från rutan (SEK, EUR, USD)", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Om det är en giltig valuta, tilldela den
            string currency = CBCurrency.Text;

            // Kontrollera att sektorn inte är tom och att första bokstaven blir stor
            if (!string.IsNullOrEmpty(sector))
            {
                sector = char.ToUpper(sector[0]) + sector.Substring(1).ToLower(); // Första bokstaven blir stor, resten små.
            }
            else
            {
                MessageBox.Show("Sektor kan inte vara tom", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int quantity = (int)NumQuantity.Value;
            int purchasePrice = (int)NumPurchasePrice.Value;

            DateTime currentDate = DateTime.Now;

            try
            {
                // Validera inmatade data
                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(symbol) || string.IsNullOrWhiteSpace(sector))
                {
                    MessageBox.Show("Alla fält måste vara ifyllda.", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (quantity <= 0)
                {
                    MessageBox.Show("Antalet aktier måste vara ett positivt tal.", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (purchasePrice <= 0)
                {
                    MessageBox.Show("Köppris måste vara ett positivt tal.", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                // kontrollerar om Sectorn redan är tillagd i databasen annars skapar den sektorn.
                int sectorID = sectorsKontroller.GetOrCreateSector(sector);

                // Här anropar du kontroller-metoden för att lägga till aktien i systemet
                int Checked = aktierKontroller.GetStockIDFromSymbol(symbol);

                if (Checked == 0)
                {
                    aktierKontroller.AddStock(name, symbol, currentPrice: purchasePrice, sectorID); // Ska Enbart köras om aktien inte är tillagd
                    int maxID = aktierKontroller.GetHighestStockID();// Ska Enbart köras om aktien inte är 
                    transactionsKontroller.CreateBuyStockTransaction(maxID, purchasePrice, quantity, currentDate, currency);
                    MessageBox.Show("Aktien har lagts till i portföljen.", "Framgång", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();
                    this.Show();
                }
                else
                {
                    transactionsKontroller.CreateBuyStockTransaction(Checked, purchasePrice, quantity, currentDate, currency);
                    MessageBox.Show("Aktien har lagts till i portföljen.", "Framgång", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();
                    this.Show();
                }
                
            }
            catch (FormatException ex)
            {
                // Specifik felhantering för formatfel, exempelvis om användaren anger ett ogiltigt nummer
                MessageBox.Show($"Fel format på indata: {ex.Message}", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Hantera andra fel som kan uppstå
                MessageBox.Show($"Ett oväntat fel inträffade: {ex.Message}", "Fel", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
