﻿namespace Presentation
{
    partial class AddStockToPortfolioMeny
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtName = new TextBox();
            txtSymbol = new TextBox();
            txtSektor = new TextBox();
            NumQuantity = new NumericUpDown();
            NumPurchasePrice = new NumericUpDown();
            label1 = new Label();
            label2 = new Label();
            AddStockBtn = new Button();
            CBCurrency = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)NumQuantity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NumPurchasePrice).BeginInit();
            SuspendLayout();
            // 
            // txtName
            // 
            txtName.Anchor = AnchorStyles.None;
            txtName.Location = new Point(312, 78);
            txtName.Name = "txtName";
            txtName.Size = new Size(147, 25);
            txtName.TabIndex = 1;
            txtName.Text = "Namn";
            txtName.TextAlign = HorizontalAlignment.Center;
            // 
            // txtSymbol
            // 
            txtSymbol.Anchor = AnchorStyles.None;
            txtSymbol.Location = new Point(312, 109);
            txtSymbol.Name = "txtSymbol";
            txtSymbol.Size = new Size(147, 25);
            txtSymbol.TabIndex = 2;
            txtSymbol.Text = "Kortnamn";
            txtSymbol.TextAlign = HorizontalAlignment.Center;
            // 
            // txtSektor
            // 
            txtSektor.Anchor = AnchorStyles.None;
            txtSektor.Location = new Point(312, 140);
            txtSektor.Name = "txtSektor";
            txtSektor.Size = new Size(147, 25);
            txtSektor.TabIndex = 3;
            txtSektor.Text = "Sektor";
            txtSektor.TextAlign = HorizontalAlignment.Center;
            // 
            // NumQuantity
            // 
            NumQuantity.Anchor = AnchorStyles.None;
            NumQuantity.Location = new Point(312, 202);
            NumQuantity.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            NumQuantity.Name = "NumQuantity";
            NumQuantity.Size = new Size(147, 25);
            NumQuantity.TabIndex = 5;
            // 
            // NumPurchasePrice
            // 
            NumPurchasePrice.Anchor = AnchorStyles.None;
            NumPurchasePrice.DecimalPlaces = 2;
            NumPurchasePrice.Location = new Point(312, 233);
            NumPurchasePrice.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
            NumPurchasePrice.Name = "NumPurchasePrice";
            NumPurchasePrice.Size = new Size(147, 25);
            NumPurchasePrice.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(234, 235);
            label1.Name = "label1";
            label1.Size = new Size(72, 19);
            label1.TabIndex = 9;
            label1.Text = "Inköpspris";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ButtonFace;
            label2.Location = new Point(265, 204);
            label2.Name = "label2";
            label2.Size = new Size(41, 19);
            label2.TabIndex = 10;
            label2.Text = "Antal";
            // 
            // AddStockBtn
            // 
            AddStockBtn.Location = new Point(312, 274);
            AddStockBtn.Name = "AddStockBtn";
            AddStockBtn.Size = new Size(147, 57);
            AddStockBtn.TabIndex = 7;
            AddStockBtn.Text = "Lägg till i portföljen";
            AddStockBtn.UseVisualStyleBackColor = true;
            AddStockBtn.Click += AddStockBtn_Click;
            // 
            // CBCurrency
            // 
            CBCurrency.Anchor = AnchorStyles.None;
            CBCurrency.DisplayMember = "SEK";
            CBCurrency.FormattingEnabled = true;
            CBCurrency.Items.AddRange(new object[] { "SEK", "EUR", "USD" });
            CBCurrency.Location = new Point(312, 171);
            CBCurrency.Name = "CBCurrency";
            CBCurrency.Size = new Size(147, 25);
            CBCurrency.TabIndex = 4;
            CBCurrency.Text = "Valuta";
            // 
            // AddStockToPortfolioMeny
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(CBCurrency);
            Controls.Add(AddStockBtn);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(NumPurchasePrice);
            Controls.Add(NumQuantity);
            Controls.Add(txtSektor);
            Controls.Add(txtSymbol);
            Controls.Add(txtName);
            Name = "AddStockToPortfolioMeny";
            Controls.SetChildIndex(txtName, 0);
            Controls.SetChildIndex(txtSymbol, 0);
            Controls.SetChildIndex(txtSektor, 0);
            Controls.SetChildIndex(NumQuantity, 0);
            Controls.SetChildIndex(NumPurchasePrice, 0);
            Controls.SetChildIndex(label1, 0);
            Controls.SetChildIndex(label2, 0);
            Controls.SetChildIndex(AddStockBtn, 0);
            Controls.SetChildIndex(CBCurrency, 0);
            ((System.ComponentModel.ISupportInitialize)NumQuantity).EndInit();
            ((System.ComponentModel.ISupportInitialize)NumPurchasePrice).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtName;
        private TextBox txtSymbol;
        private TextBox txtSektor;
        private NumericUpDown NumQuantity;
        private NumericUpDown NumPurchasePrice;
        private Label label1;
        private Label label2;
        private Button AddStockBtn;
        private ComboBox CBCurrency;
    }
}