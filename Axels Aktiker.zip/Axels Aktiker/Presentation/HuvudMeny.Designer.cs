﻿namespace Presentation
{
    partial class HuvudMeny
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            PortfolioBtn = new Button();
            StocksBtn = new Button();
            rapporterBtn = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // PortfolioBtn
            // 
            PortfolioBtn.Anchor = AnchorStyles.None;
            PortfolioBtn.AutoSize = true;
            PortfolioBtn.Location = new Point(179, 110);
            PortfolioBtn.Name = "PortfolioBtn";
            PortfolioBtn.Size = new Size(134, 75);
            PortfolioBtn.TabIndex = 0;
            PortfolioBtn.Text = "Innehav";
            PortfolioBtn.UseVisualStyleBackColor = true;
            PortfolioBtn.Click += PortfolioBtn_Click;
            // 
            // StocksBtn
            // 
            StocksBtn.Anchor = AnchorStyles.None;
            StocksBtn.AutoSize = true;
            StocksBtn.Location = new Point(453, 110);
            StocksBtn.Name = "StocksBtn";
            StocksBtn.Size = new Size(134, 75);
            StocksBtn.TabIndex = 1;
            StocksBtn.Text = "Värdepapper?";
            StocksBtn.UseVisualStyleBackColor = true;
            StocksBtn.Click += StocksBtn_Click;
            // 
            // rapporterBtn
            // 
            rapporterBtn.Anchor = AnchorStyles.None;
            rapporterBtn.AutoSize = true;
            rapporterBtn.Location = new Point(179, 256);
            rapporterBtn.Name = "rapporterBtn";
            rapporterBtn.Size = new Size(134, 75);
            rapporterBtn.TabIndex = 2;
            rapporterBtn.Text = "Rapporter";
            rapporterBtn.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.AutoSize = true;
            button1.Location = new Point(453, 256);
            button1.Name = "button1";
            button1.Size = new Size(134, 75);
            button1.TabIndex = 3;
            button1.Text = "Rapporter";
            button1.UseVisualStyleBackColor = true;
            // 
            // HuvudMeny
            // 
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(46, 46, 46);
            ClientSize = new Size(800, 510);
            Controls.Add(button1);
            Controls.Add(rapporterBtn);
            Controls.Add(StocksBtn);
            Controls.Add(PortfolioBtn);
            Name = "HuvudMeny";
            Text = "Axels Aktier";
            Controls.SetChildIndex(PortfolioBtn, 0);
            Controls.SetChildIndex(StocksBtn, 0);
            Controls.SetChildIndex(rapporterBtn, 0);
            Controls.SetChildIndex(button1, 0);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button PortfolioBtn;
        private Button StocksBtn;
        private Button rapporterBtn;
        private Button button1;
    }
}
