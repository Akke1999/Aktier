using Aff�rslager;


namespace Presentation
{
    public partial class HuvudMeny : BaseForm
    {
        public HuvudMeny()
        {
            InitializeComponent();
            HideReturnButton();
        }

        private void PortfolioBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            PortfolioMeny portfolioMeny = new PortfolioMeny();
            portfolioMeny.Show();

        }

        private void StocksBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocksMeny stocksMeny = new StocksMeny();
            stocksMeny.Show();
        }


    }
}
