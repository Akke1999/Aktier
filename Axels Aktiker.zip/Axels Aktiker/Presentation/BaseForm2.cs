﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class BaseForm2:Form
    {
        private Button returnButton2;
        public BaseForm2()

        {
            //Färg
            this.BackColor = Color.FromArgb(46, 46, 46);

            //Fönster
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(800, 600);

            //Font
            this.Font = new Font("Segoe UI", 10);

            //Lite mer stillat
            this.FormBorderStyle = FormBorderStyle.FixedDialog; // Ingen fönsterförändring
            this.MaximizeBox = false; // Ingen maximering
            this.Text = "Axels Aktier";

            InitalizeReturnButton2();
        }


        private void InitalizeReturnButton2()
        {
            returnButton2 = new Button
            {
                Size = new Size(40, 30),
                Location = new Point(12, 47),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                BackgroundImage = Properties.Resources.PilBakåt,
                BackgroundImageLayout = ImageLayout.Stretch,
                FlatAppearance = { BorderSize = 0, }
            };

            returnButton2.Click += ReturnButton2_Click;
            this.Controls.Add(returnButton2);
        }

        private void ReturnButton2_Click(object sender, EventArgs e)
        {
            this.Close(); // Stäng formuläret
            PortfolioMeny portfolioMeny = new PortfolioMeny();
            portfolioMeny.Show();
        }
    }
}
